$(function () {
    $("#wrap a[target]").css({"color" : "#f00"});

$("#wrap a[href^=https]").css({"color" : "#0f0"});

$("wrap a[href$=net]").css({"color" : "#00f"});

$("#wrap a[href*=google]").css({"color" : "#000"});

$("#member_f:text").css({"background-color" : "#ff0"});

});
